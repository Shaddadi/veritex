This folder stores all repaired networks without the refinement method
