This folder stores all repaired networks with the refinement method
